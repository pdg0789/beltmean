class User < ActiveRecord::Base
  has_secure_password

  has_many :secrets, dependent: :destroy
  has_many :likes, dependent: :destroy
  has_many :secrets_liked, through: :likes, source: :secret

  email_regex = /\A([\w+\-].?)+@[a-z\d\-]+(\.[a-z]+)*\.[a-z]+\z/i
  validates :first_name, :last_name, :email, presence: true
  validates :email, uniqueness: true, format: { with: email_regex }
  validates_presence_of :password_confirmation, if: :password_digest_changed?
end
