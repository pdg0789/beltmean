Rails.application.routes.draw do
 get 'secrets/index'

 root "users#index"
 get 'sessions/new'
 get 'register' => 'users#new'
 post '/users' => 'users#create'
 get 'users/:id' => 'users#show'
 get '/edit/:id'=> 'users#edit'
 patch 'users/:id' => 'users#update'
 get 'login' => 'sessions#new'
 post 'login' => 'sessions#create'
 delete 'logout' => 'sessions#destroy'
 delete '/delete/:id' => 'users#delete'
 get "/secrets" => "secrets#index"
 post "/secrets" => "secrets#create"
 delete "/secrets/:secret_id" => "secrets#destroy"
 post "likes/:secret_id" => "likes#create"
 delete "/likes/:secrets_id" => "likes#destroy"
end
