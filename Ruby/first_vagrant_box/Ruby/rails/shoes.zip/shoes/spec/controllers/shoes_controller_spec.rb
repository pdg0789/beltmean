require 'rails_helper'

RSpec.describe ShoesController, type: :controller do

end
