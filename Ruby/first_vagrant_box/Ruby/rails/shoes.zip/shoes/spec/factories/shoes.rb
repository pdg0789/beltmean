FactoryGirl.define do
  factory :shoe do
    name "MyString"
    price 1
    user nil
  end
end
