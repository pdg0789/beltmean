class Comment < ActiveRecord::Base
  belongs_to :user, required: true
  belongs_to :event, required: true


  validates :context, presence: true, length: 2..160
end
